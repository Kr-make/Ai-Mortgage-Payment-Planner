import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from model import (
    MortgagePipeline, FeatureEngineer, ModelFactory,
    DataValidator, Evaluator, ArtifactManager, Config,
)

import streamlit as st
import joblib
import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from pathlib import Path

st.set_page_config(
    page_title="MortgageIQ — Loan Intelligence Platform",
    page_icon="🏛️",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:wght@300;400;500;600&display=swap');

html, body, [class*="css"] { font-family: 'DM Sans', sans-serif; }

.main-title {
    font-family: 'DM Serif Display', serif;
    font-size: 2.8rem;
    letter-spacing: -0.02em;
    line-height: 1.1;
    color: #0f1923;
    margin-bottom: 0.2rem;
}
.subtitle {
    font-size: 1rem;
    color: #64748b;
    font-weight: 300;
    letter-spacing: 0.04em;
    text-transform: uppercase;
    margin-bottom: 2rem;
}
.kpi-card {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 16px;
    padding: 1.4rem 1.6rem;
    border-left: 4px solid #1e40af;
    box-shadow: 0 1px 3px rgba(0,0,0,0.04);
}
.kpi-label {
    font-size: 0.72rem;
    font-weight: 600;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    color: #94a3b8;
    margin-bottom: 0.3rem;
}
.kpi-value {
    font-family: 'DM Serif Display', serif;
    font-size: 1.9rem;
    color: #0f172a;
    line-height: 1;
}
.kpi-sub { font-size: 0.78rem; color: #64748b; margin-top: 0.3rem; }
.risk-safe {
    background: linear-gradient(135deg, #ecfdf5, #d1fae5);
    border-left-color: #059669;
    border-color: #a7f3d0;
}
.risk-warning {
    background: linear-gradient(135deg, #fffbeb, #fef3c7);
    border-left-color: #d97706;
    border-color: #fde68a;
}
.risk-danger {
    background: linear-gradient(135deg, #fff1f2, #ffe4e6);
    border-left-color: #dc2626;
    border-color: #fecdd3;
}
.section-header {
    font-family: 'DM Serif Display', serif;
    font-size: 1.4rem;
    color: #0f172a;
    margin-bottom: 0.2rem;
    margin-top: 2rem;
}
.section-sub {
    font-size: 0.82rem;
    color: #94a3b8;
    margin-bottom: 1rem;
    font-weight: 300;
}
.stButton > button {
    background: #1e40af;
    color: white;
    border: none;
    border-radius: 10px;
    padding: 0.7rem 2rem;
    font-family: 'DM Sans', sans-serif;
    font-weight: 600;
    font-size: 0.9rem;
    letter-spacing: 0.05em;
    width: 100%;
    transition: all 0.2s;
}
.stButton > button:hover {
    background: #1e3a8a;
    transform: translateY(-1px);
    box-shadow: 0 4px 20px rgba(30,64,175,0.3);
}
.insight-box {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    padding: 1rem 1.2rem;
    margin-bottom: 0.6rem;
    font-size: 0.88rem;
    color: #334155;
    line-height: 1.6;
}
div[data-testid="stSidebar"] { background: #0f172a; }
div[data-testid="stSidebar"] * { color: #cbd5e1 !important; }
div[data-testid="stSidebar"] label {
    color: #94a3b8 !important;
    font-size: 0.8rem !important;
    font-weight: 500 !important;
    letter-spacing: 0.06em !important;
    text-transform: uppercase !important;
}
.sidebar-title {
    font-family: 'DM Serif Display', serif;
    font-size: 1.3rem;
    color: #f1f5f9 !important;
    margin-bottom: 0.2rem;
}
.sidebar-sub { font-size: 0.75rem; color: #64748b !important; margin-bottom: 1.5rem; }
</style>
""", unsafe_allow_html=True)


@st.cache_resource
def load_model():
    path = Path("models/risk_model.pkl")
    if not path.exists():
        return None
    bundle = joblib.load(path)
    return bundle if isinstance(bundle, dict) else {"model": bundle}


def calculate_emi(principal: float, annual_rate: float, years: int) -> float:
    r = annual_rate / (12 * 100)
    n = years * 12
    if r == 0:
        return principal / n
    return (principal * r * (1 + r) ** n) / ((1 + r) ** n - 1)


def emi_schedule(principal: float, annual_rate: float, years: int) -> pd.DataFrame:
    r = annual_rate / (12 * 100)
    emi = calculate_emi(principal, annual_rate, years)
    rows, balance = [], principal
    for month in range(1, int(years * 12) + 1):
        interest_part = balance * r
        principal_part = emi - interest_part
        balance = max(balance - principal_part, 0)
        rows.append({
            "Month": month, "Year": (month - 1) // 12 + 1,
            "EMI": emi, "Principal": principal_part,
            "Interest": interest_part, "Balance": balance,
        })
    return pd.DataFrame(rows)


def affordability_scenarios(income: float, annual_rate: float, tenure: int) -> pd.DataFrame:
    rows = []
    for la in np.arange(500_000, 10_000_000, 500_000):
        emi = calculate_emi(la, annual_rate, tenure)
        ratio = emi / income if income > 0 else 0
        rows.append({
            "Loan Amount (₹L)": la / 1e5, "EMI": emi, "Ratio": ratio,
            "Status": "Safe" if ratio <= 0.3 else ("Moderate" if ratio <= 0.5 else "Risky"),
        })
    return pd.DataFrame(rows)


def rate_sensitivity(principal: float, income: float, tenure: int) -> pd.DataFrame:
    rows = []
    for rate in np.arange(6.0, 16.5, 0.5):
        emi = calculate_emi(principal, rate, tenure)
        rows.append({"Rate (%)": round(rate, 1), "EMI": emi, "Ratio": emi / income if income > 0 else 0})
    return pd.DataFrame(rows)


def tenure_impact(principal: float, annual_rate: float, income: float) -> pd.DataFrame:
    rows = []
    for t in range(5, 31):
        emi = calculate_emi(principal, annual_rate, t)
        total = emi * t * 12
        rows.append({
            "Tenure (Yrs)": t, "EMI": emi,
            "Total Interest": total - principal, "Total Payment": total,
            "Ratio": emi / income if income > 0 else 0,
        })
    return pd.DataFrame(rows)


def risk_gauge(ratio: float) -> go.Figure:
    fig = go.Figure(go.Indicator(
        mode="gauge+number+delta",
        value=round(ratio * 100, 1),
        number={"suffix": "%", "font": {"size": 32, "family": "DM Serif Display"}},
        delta={"reference": 30, "valueformat": ".1f", "suffix": "%"},
        title={"text": "EMI / Income Ratio", "font": {"size": 13, "color": "#64748b", "family": "DM Sans"}},
        gauge={
            "axis": {"range": [0, 80], "ticksuffix": "%", "tickfont": {"size": 11}},
            "bar": {"color": "#1e40af", "thickness": 0.25},
            "steps": [
                {"range": [0, 30], "color": "#d1fae5"},
                {"range": [30, 50], "color": "#fef3c7"},
                {"range": [50, 80], "color": "#ffe4e6"},
            ],
            "threshold": {"line": {"color": "#dc2626", "width": 2}, "thickness": 0.75, "value": 50},
        }
    ))
    fig.update_layout(
        height=240, margin=dict(l=20, r=20, t=40, b=10),
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        font={"family": "DM Sans"},
    )
    return fig


def amortization_chart(schedule: pd.DataFrame) -> go.Figure:
    yearly = schedule.groupby("Year")[["Principal", "Interest", "Balance"]].agg(
        {"Principal": "sum", "Interest": "sum", "Balance": "last"}
    ).reset_index()
    fig = make_subplots(specs=[[{"secondary_y": True}]])
    fig.add_trace(go.Bar(x=yearly["Year"], y=yearly["Principal"], name="Principal",
                         marker_color="#1e40af", opacity=0.85), secondary_y=False)
    fig.add_trace(go.Bar(x=yearly["Year"], y=yearly["Interest"], name="Interest",
                         marker_color="#93c5fd", opacity=0.85), secondary_y=False)
    fig.add_trace(go.Scatter(x=yearly["Year"], y=yearly["Balance"], name="Outstanding Balance",
                             mode="lines+markers", line={"color": "#dc2626", "width": 2, "dash": "dot"},
                             marker={"size": 5}), secondary_y=True)
    fig.update_layout(
        barmode="stack", height=340, margin=dict(l=0, r=0, t=10, b=0),
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        legend={"orientation": "h", "y": -0.18, "font": {"size": 11}},
        font={"family": "DM Sans", "size": 11},
        xaxis={"title": "Year", "showgrid": False},
        yaxis={"title": "Amount (₹)", "showgrid": True, "gridcolor": "#f1f5f9"},
        yaxis2={"title": "Balance (₹)", "showgrid": False},
    )
    return fig


def affordability_chart(df: pd.DataFrame, current_loan: float) -> go.Figure:
    color_map = {"Safe": "#059669", "Moderate": "#d97706", "Risky": "#dc2626"}
    fig = go.Figure()
    for status in ["Safe", "Moderate", "Risky"]:
        subset = df[df["Status"] == status]
        fig.add_trace(go.Bar(x=subset["Loan Amount (₹L)"], y=subset["EMI"],
                             name=status, marker_color=color_map[status], opacity=0.85))
    fig.add_vline(x=current_loan / 1e5, line_dash="dash", line_color="#0f172a",
                  annotation_text="Your Loan", annotation_position="top", annotation_font_size=11)
    fig.update_layout(
        barmode="stack", height=300, margin=dict(l=0, r=0, t=10, b=0),
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        xaxis={"title": "Loan Amount (₹ Lakh)", "showgrid": False},
        yaxis={"title": "Monthly EMI (₹)", "gridcolor": "#f1f5f9"},
        legend={"orientation": "h", "y": -0.22, "font": {"size": 11}},
        font={"family": "DM Sans", "size": 11},
    )
    return fig


def rate_sensitivity_chart(df: pd.DataFrame, current_rate: float) -> go.Figure:
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=df["Rate (%)"], y=df["EMI"], mode="lines+markers",
        line={"color": "#1e40af", "width": 2.5},
        marker={"size": 5, "color": df["Ratio"].apply(
            lambda r: "#059669" if r <= 0.3 else ("#d97706" if r <= 0.5 else "#dc2626")
        )},
        fill="tozeroy", fillcolor="rgba(30,64,175,0.05)",
    ))
    fig.add_vline(x=current_rate, line_dash="dash", line_color="#dc2626",
                  annotation_text=f"Your rate: {current_rate}%",
                  annotation_position="top right", annotation_font_size=11)
    fig.update_layout(
        height=280, margin=dict(l=0, r=0, t=10, b=0),
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        xaxis={"title": "Interest Rate (%)", "showgrid": False},
        yaxis={"title": "Monthly EMI (₹)", "gridcolor": "#f1f5f9"},
        font={"family": "DM Sans", "size": 11},
    )
    return fig


def tenure_chart(df: pd.DataFrame, current_tenure: int) -> go.Figure:
    fig = make_subplots(specs=[[{"secondary_y": True}]])
    fig.add_trace(go.Scatter(x=df["Tenure (Yrs)"], y=df["EMI"], name="Monthly EMI",
                             mode="lines+markers", line={"color": "#1e40af", "width": 2.5},
                             marker={"size": 5}), secondary_y=False)
    fig.add_trace(go.Scatter(x=df["Tenure (Yrs)"], y=df["Total Interest"], name="Total Interest Paid",
                             mode="lines+markers", line={"color": "#dc2626", "width": 2, "dash": "dot"},
                             marker={"size": 5}), secondary_y=True)
    fig.add_vline(x=current_tenure, line_dash="dash", line_color="#64748b",
                  annotation_text=f"{current_tenure} Yrs",
                  annotation_position="top", annotation_font_size=11)
    fig.update_layout(
        height=280, margin=dict(l=0, r=0, t=10, b=0),
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        xaxis={"title": "Tenure (Years)", "showgrid": False},
        yaxis={"title": "EMI (₹)", "gridcolor": "#f1f5f9"},
        yaxis2={"title": "Total Interest (₹)", "showgrid": False},
        legend={"orientation": "h", "y": -0.22, "font": {"size": 11}},
        font={"family": "DM Sans", "size": 11},
    )
    return fig


def payment_donut(principal: float, total_interest: float) -> go.Figure:
    fig = go.Figure(go.Pie(
        labels=["Principal", "Interest"],
        values=[principal, total_interest],
        hole=0.6,
        marker={"colors": ["#1e40af", "#93c5fd"]},
        textfont={"family": "DM Sans", "size": 12},
    ))
    fig.update_layout(
        height=240, margin=dict(l=10, r=10, t=10, b=10),
        paper_bgcolor="rgba(0,0,0,0)", showlegend=True,
        legend={"orientation": "h", "y": -0.1, "font": {"size": 11}},
        font={"family": "DM Sans"},
        annotations=[{"text": "Breakdown", "x": 0.5, "y": 0.5, "showarrow": False,
                       "font": {"size": 12, "color": "#64748b", "family": "DM Serif Display"}}],
    )
    return fig


def ai_predict(model_bundle, income, loan_amount, interest_rate, tenure, emi,
               credit_score, existing_emi, employment_years, loan_purpose):
    if model_bundle is None:
        return None, None
    try:
        model_obj = model_bundle.get("model")
        feature_names = model_bundle.get("feature_names", [])
        fe = model_bundle.get("feature_engineer")

        purpose_map = {"home": 0, "renovation": 1, "plot": 2, "construction": 3}
        emi_ratio = emi / income if income > 0 else 0
        total_burden = (emi + existing_emi) / income if income > 0 else 0
        ltv = loan_amount / (income * 12 * 5) if income > 0 else 0

        row = {
            "income": income, "loan_amount": loan_amount,
            "interest_rate": interest_rate, "tenure": tenure, "emi": emi,
            "credit_score": credit_score, "existing_emi": existing_emi,
            "employment_years": employment_years, "loan_purpose": loan_purpose,
            "emi_ratio": emi_ratio, "total_burden": total_burden, "ltv": ltv,
        }
        df_row = pd.DataFrame([row])

        if fe is not None:
            df_row = fe.transform(df_row)

        if feature_names:
            available = [f for f in feature_names if f in df_row.columns]
            df_row = df_row[available]

        pred = model_obj.predict(df_row)[0]
        proba = model_obj.predict_proba(df_row)[0][1] if hasattr(model_obj, "predict_proba") else None
        return pred, proba
    except Exception as e:
        st.warning(f"AI prediction skipped: {e}")
        return None, None


with st.sidebar:
    st.markdown('<div class="sidebar-title">MortgageIQ</div>', unsafe_allow_html=True)
    st.markdown('<div class="sidebar-sub">Loan Intelligence Platform</div>', unsafe_allow_html=True)
    st.markdown("---")

    income = st.number_input("Monthly Income (₹)", min_value=10_000, max_value=10_000_000,
                              value=100_000, step=5_000, format="%d")
    loan_amount = st.number_input("Loan Amount (₹)", min_value=100_000, max_value=50_000_000,
                                   value=3_000_000, step=100_000, format="%d")
    interest_rate = st.number_input("Interest Rate (%)", min_value=1.0, max_value=20.0,
                                     value=8.5, step=0.1, format="%.1f")
    tenure = st.number_input("Tenure (Years)", min_value=1, max_value=30, value=20, step=1)
    credit_score = st.slider("Credit Score", 300, 900, 720, 10)
    existing_emi = st.number_input("Existing EMIs / Month (₹)", min_value=0, value=0, step=1_000)
    employment_years = st.slider("Years of Employment", 0, 40, 5)
    loan_purpose = st.selectbox("Loan Purpose", ["home", "renovation", "plot", "construction"])

    st.markdown("---")
    analyze = st.button("⚡ Analyze Loan")


st.markdown('<div class="main-title">Loan Intelligence<br>Dashboard</div>', unsafe_allow_html=True)
st.markdown('<div class="subtitle">AI-powered mortgage risk & affordability analysis</div>', unsafe_allow_html=True)

if analyze:
    emi = calculate_emi(loan_amount, interest_rate, tenure)
    total_payment = emi * tenure * 12
    total_interest = total_payment - loan_amount
    emi_ratio = emi / income if income > 0 else 0
    total_emi_burden = (emi + existing_emi) / income if income > 0 else 0
    schedule = emi_schedule(loan_amount, interest_rate, tenure)

    if emi_ratio <= 0.3:
        risk_css, risk_label, risk_icon = "risk-safe", "SAFE", "✅"
    elif emi_ratio <= 0.5:
        risk_css, risk_label, risk_icon = "risk-warning", "MODERATE", "⚠️"
    else:
        risk_css, risk_label, risk_icon = "risk-danger", "HIGH RISK", "🚨"

    model_bundle = load_model()
    ai_pred, ai_proba = ai_predict(
        model_bundle, income, loan_amount, interest_rate,
        tenure, emi, credit_score, existing_emi, employment_years, loan_purpose
    )

    k1, k2, k3, k4, k5 = st.columns(5)
    with k1:
        st.markdown(f"""<div class="kpi-card">
            <div class="kpi-label">Monthly EMI</div>
            <div class="kpi-value">₹{emi:,.0f}</div>
            <div class="kpi-sub">per month</div></div>""", unsafe_allow_html=True)
    with k2:
        st.markdown(f"""<div class="kpi-card">
            <div class="kpi-label">Total Interest</div>
            <div class="kpi-value">₹{total_interest/1e5:.1f}L</div>
            <div class="kpi-sub">over {tenure} years</div></div>""", unsafe_allow_html=True)
    with k3:
        st.markdown(f"""<div class="kpi-card">
            <div class="kpi-label">Total Payment</div>
            <div class="kpi-value">₹{total_payment/1e5:.1f}L</div>
            <div class="kpi-sub">principal + interest</div></div>""", unsafe_allow_html=True)
    with k4:
        st.markdown(f"""<div class="kpi-card">
            <div class="kpi-label">EMI / Income</div>
            <div class="kpi-value">{emi_ratio*100:.1f}%</div>
            <div class="kpi-sub">debt burden ratio</div></div>""", unsafe_allow_html=True)
    with k5:
        ai_sub = ""
        if ai_pred is not None:
            ai_label = "Safe" if ai_pred == 0 else "Risky"
            ai_sub = f"AI: {ai_label}" + (f" ({ai_proba*100:.0f}% risk)" if ai_proba is not None else "")
        st.markdown(f"""<div class="kpi-card {risk_css}">
            <div class="kpi-label">Risk Level</div>
            <div class="kpi-value">{risk_icon}</div>
            <div class="kpi-sub">{risk_label}{(' · ' + ai_sub) if ai_sub else ''}</div></div>""",
                    unsafe_allow_html=True)

    st.markdown('<div class="section-header">Risk & Payment Breakdown</div>', unsafe_allow_html=True)
    st.markdown('<div class="section-sub">Gauge shows EMI as a share of income — safe zone is under 30%</div>', unsafe_allow_html=True)
    g1, g2 = st.columns([1.6, 1])
    with g1:
        st.plotly_chart(risk_gauge(emi_ratio), use_container_width=True)
    with g2:
        st.plotly_chart(payment_donut(loan_amount, total_interest), use_container_width=True)

    st.markdown('<div class="section-header">Amortization Schedule</div>', unsafe_allow_html=True)
    st.markdown('<div class="section-sub">Year-by-year principal, interest, and outstanding balance</div>', unsafe_allow_html=True)
    st.plotly_chart(amortization_chart(schedule), use_container_width=True)

    st.markdown('<div class="section-header">Affordability Landscape</div>', unsafe_allow_html=True)
    st.markdown('<div class="section-sub">All loan amounts at your rate & tenure — yours is marked</div>', unsafe_allow_html=True)
    st.plotly_chart(affordability_chart(affordability_scenarios(income, interest_rate, tenure), loan_amount),
                    use_container_width=True)

    c1, c2 = st.columns(2)
    with c1:
        st.markdown('<div class="section-header">Rate Sensitivity</div>', unsafe_allow_html=True)
        st.markdown('<div class="section-sub">EMI movement across 6%–16% interest rates</div>', unsafe_allow_html=True)
        st.plotly_chart(rate_sensitivity_chart(rate_sensitivity(loan_amount, income, tenure), interest_rate),
                        use_container_width=True)
    with c2:
        st.markdown('<div class="section-header">Tenure Trade-off</div>', unsafe_allow_html=True)
        st.markdown('<div class="section-sub">Lower EMI vs. higher total interest cost</div>', unsafe_allow_html=True)
        st.plotly_chart(tenure_chart(tenure_impact(loan_amount, interest_rate, income), tenure),
                        use_container_width=True)

    st.markdown('<div class="section-header">Actionable Insights</div>', unsafe_allow_html=True)
    insights = []

    if emi_ratio > 0.5:
        alt_tenure = next((t for t in range(tenure + 1, 31)
                           if calculate_emi(loan_amount, interest_rate, t) / income <= 0.4), None)
        if alt_tenure:
            insights.append(f"📅 Extending to <b>{alt_tenure} years</b> drops your ratio to 40% — EMI becomes ₹{calculate_emi(loan_amount, interest_rate, alt_tenure):,.0f}.")
        safe_loan = next((la for la in range(loan_amount, 100_000, -100_000)
                          if calculate_emi(la, interest_rate, tenure) / income <= 0.4), None)
        if safe_loan:
            insights.append(f"💰 Reducing loan to <b>₹{safe_loan/1e5:.0f}L</b> keeps EMI at 40% — a larger down payment would help.")

    if existing_emi > 0 and total_emi_burden > 0.5:
        insights.append(f"⚡ Combined EMI burden is <b>{total_emi_burden*100:.1f}%</b> of income — consider clearing existing debt first.")

    if credit_score >= 750:
        better_rate = max(interest_rate - 0.5, 6.5)
        savings = (emi - calculate_emi(loan_amount, better_rate, tenure)) * tenure * 12
        insights.append(f"🏆 Credit score {credit_score} qualifies for better rates — at {better_rate}% you'd save ₹{savings:,.0f} overall.")
    elif credit_score < 650:
        insights.append(f"📈 Score of {credit_score} may attract higher rates. Improving to 750+ before applying could save lakhs.")

    if employment_years < 2:
        insights.append("🏢 Under 2 years of employment history may affect lender confidence — some banks require at least 2 years.")

    interest_pct = (total_interest / loan_amount) * 100
    insights.append(f"📊 Interest cost is <b>{interest_pct:.0f}%</b> of principal (₹{total_interest/1e5:.1f}L). A ₹{loan_amount*0.05/1e5:.1f}L prepayment in year 1 can meaningfully cut this.")

    if emi_ratio <= 0.3:
        insights.append(f"✅ EMI ratio of {emi_ratio*100:.1f}% is healthy. Lenders typically approve up to 40% comfortably.")

    for insight in insights:
        st.markdown(f'<div class="insight-box">{insight}</div>', unsafe_allow_html=True)

    with st.expander("📋 Full Amortization Table"):
        fmt = {c: "₹{:,.0f}" for c in ["EMI", "Principal", "Interest", "Balance"]}
        st.dataframe(
            schedule[["Month", "Year", "EMI", "Principal", "Interest", "Balance"]].style.format(fmt),
            use_container_width=True, height=300,
        )

else:
    st.markdown("""
    <div style="text-align:center; padding: 5rem 2rem; color: #94a3b8;">
        <div style="font-size: 3.5rem; margin-bottom: 1rem;">🏛️</div>
        <div style="font-family: 'DM Serif Display', serif; font-size: 1.6rem; color: #64748b; margin-bottom: 0.5rem;">
            Enter your loan details
        </div>
        <div style="font-size: 0.9rem; font-weight: 300;">
            Fill in the sidebar and click <strong>Analyze Loan</strong> to see your full dashboard
        </div>
    </div>
    """, unsafe_allow_html=True)
